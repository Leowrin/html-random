var result =-1;
var x;
var y;

function load() {
  alert("Here are the basic rules my chonchon :D\n\n1.\tClick on start to start\n\n2.\tThen, Shrempfs will pop randomly on your screen,\n\t kill them by clicking on their heads.\n\n\n(works best with FireFox or Chrome)")
}

function back(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/yfwaJWNEEZQys/giphy.gif')";
  setTimeout(back2, 4500);
}
function back2(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/TmH5Zk8cbbqrS/giphy.gif')";
  setTimeout(back3, 4000);
}
function back3(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/SW5k2eirzkzAc/giphy.gif')";
  setTimeout(back4, 3500);
}
function back4(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/MDXomrcGshGso/giphy.gif')";
  setTimeout(back5, 3000);
}
function back5(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/rB2kEXJhDR5mM/giphy.gif')";
  setTimeout(back6, 2500);
}
function back6(){
  document.getElementById("maindiv").style.backgroundImage = "url('https://media.giphy.com/media/rbKtQJTxJQwBW/giphy.gif')";
  setTimeout(end, 2000);
}



function kerekstart(){
  var d = document.getElementById('tocastrate');
  x = Math.floor((Math.random() * 90) + 1);
  y = Math.floor((Math.random() * 90) + 1);
  result++
  document.getElementById("tocastrate").style.backgroundImage = "url('content/kerek.jpg')";//url('kerek.jpg')
  d.style.position = "absolute";
  d.style.left = x+'%';
  d.style.top = y+'%';

}

function end() {
 alert("Your Score : "+result);
}
