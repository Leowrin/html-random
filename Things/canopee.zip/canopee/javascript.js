function test() {
var exercice;
exercice = document.getElementById("exs").value;

switch (exercice) {
  case "ex1":
    ex1();
    break;
  case "ex2":
    ex2();
    break;
  case "ex3":
    ex3();
    break;
  case ":D":
  	ui();
  	break;  			
}
}

function manger(){
 var rep, text;
 rep=prompt("Hello.. \nQue désirez vous manger?\n\ntartine500g\nsouflakis\n(prière d'écrire correktemenz)");

 switch (rep) {
   case "tartine500g":
     text = "omg mais 500g de beurre sur une tartine t'es infâme";
     break;

   case "souflakis":
      text = "tu devrais prendre l'autre..";
      break;

   default:
     text = "Merci d'entrer le nom exacte devotre commande.";
     break;
   }
 alert(text);
 }

function ex1(){
var x=2;
var y=3;
alert("x="+x+"; y="+y);
x = ""+x+y;
y = x.substr(0,1);
x = x.substr(1,2);
alert("x="+x+"; y="+y);
}

function ex2() {
  var x, y, z;
  z=prompt("entrez une fonction, + ou - ou * ou /");
  switch (z) {
    case "+":
      x=parseFloat(prompt("entrez une valeur de x (equation de type x + y = )"));
      y=parseFloat(prompt("entrez une valeur de y (equation de type "+x+" + y = )"));
      alert(x+"+"+y+"="+(x+y));
      break;

      case "-":
        x=parseFloat(prompt("entrez une valeur de x (equation de type x - y = )"));
        y=parseFloat(prompt("entrez une valeur de y (equation de type "+x+" - y = )"));
        alert(x+"-"+y+"="+(x-y));
        break;

        case "*":
          x=parseFloat(prompt("entrez une valeur de x (equation de type x*y = )"));
          y=parseFloat(prompt("entrez une valeur de y (equation de type "+x+"*y = )"));
          alert(x+"*"+y+"="+(x*y));
          break;

          case "/":
            x=parseFloat(prompt("X (equation de type x/y = )"));
            y=parseFloat(prompt("Y (equation de type "+x+"/y = )"));
            alert(x+"/"+y+"="+(x/y));
            break;
    default:
    alert("tauvin fils de pute");
    break;
  }
}

function ex3(){
}


var entry;
function ui(){
entry = prompt('écrivez "hamster noir au chocolat"');
document.body.style.backgroundImage = "url('https://media.giphy.com/media/JBP8eDB1rhIv6/giphy.gif')";
document.getElementByClass("text").style.animationName ="dd";

setTimeout(useless, 2000);
}

function useless(){
alert('Ah, et tu as écris '+entry+' pour rien....  ');
}


